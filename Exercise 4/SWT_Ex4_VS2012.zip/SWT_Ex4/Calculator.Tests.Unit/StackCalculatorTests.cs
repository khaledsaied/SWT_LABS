﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using Calculator;

namespace Calculator.Tests.Unit
{
    [TestFixture]
    public class StackCalculatorTests
    {
        [Test]
        public void You_Should_Insert_Your_Own_Tests_Here()
        {
        }
    }
}
