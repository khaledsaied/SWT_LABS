﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Calculator
{
    public interface IStackCalculator
    {
        void Push(double param); // Push param on top of stack

        double Pop();            // Pop topmost value of stack and return it
                                 // Throws InvalidOperationException if the stack is empty

        double Add();            // Replace the two topmost values on the stack with their sum
                                 // Throws ArgumentException if there are less than 2 values on the stack

        double Sub();            // Replace the two topmost values on the stack with their difference. The
                                 // topmost value is subtracted from the one below.
                                 // Throws ArgumentException if there are less than 2 values on the stack

        double Mul();            // Replace the two topmost values on the stack with their sum
                                 // Throws ArgumentException if there are less than 2 values on the stack

        double Div();            // Replace the two topmost values on the stack with their sum. The topmost
                                 // value is used to divide the one below.
                                 // Throws ArgumentException if there are less than 2 values on the stack
                                 // Throws DivideByZeroException if the topmost value is 0.

        void Clear();            // Clears all content from the stack

        int Size { get; }        // Read-only property that holds the number of elements currently in the stack

        double this[int index]   // Indexer that allows a user to view (read-only) the contents of the stack
        {                        // If there are 5 values on the stack, index 0 returns the bottom-most value
            get;                 // and index 4 returns the topmost value. If the index is out of bounds
        }                        // (i.e. < 0 or >= Size()) an IndexOutOfRangeException is thrown.
    }

    public class StackCalculator : IStackCalculator
    {
        private readonly Stack<double> _stack = new Stack<double>();
 
        public void Push(double param)
        {
            _stack.Push(param);
        }

        public double Pop()
        {
            return _stack.Pop();
        }

        public double Add()
        {
            throw new NotImplementedException();
        }

        public double Sub()
        {
            throw new NotImplementedException();
        }

        public double Mul()
        {
            throw new NotImplementedException();
        }

        public double Div()
        {
            throw new NotImplementedException();
        }

        public void Clear()
        {
            throw new NotImplementedException();
        }

        public int Size
        {
            get { return _stack.Count; }
        }

        public double this[int index]
        {
            get
            {
                if (index < 0 || index >= _stack.Count)
                    throw new IndexOutOfRangeException();
                return _stack.ElementAt(_stack.Count-index-1);
            }
        }
    }
}
