﻿using NUnit.Framework;


namespace WeighingSystem.Test
{
    [TestFixture]
    public class WeighingUnitTest
    {
    }
}
